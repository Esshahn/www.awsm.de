


This is the MOS TECHNOLOGY, INC. logo
Recreated by awsm http://www.awsm.de

Included formats are PNG with transparency and SVG vector format.
The black version is the original, the colored version is my version I created for a T-Shirt.
The font used for the subline is a Century Gothic.

Feel free to use the logo, but keep in mind that I do not own any rights to this.

