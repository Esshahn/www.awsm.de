README

In this ZIP you'll find labels similar to those used by Commodore for their

Commodore VIC20
Commodore C16
Commodore C128

computers. Actually Commodore has made about as many different labels for the machines as revisions exist, so there are many different ones and the one you remember from your childhood might be a bit different from the version I made for you.

These labels where meant to be used with RetroPie ( https://retropie.org.uk/ ), a nice emulation distro for the Raspberry Pi that, among many others, has a pretty decent VICE version.

I'm too lazy right now to give a full tutorial on how to implement these, but if you're really struggling and desperately want these labels to appear in RetroPie, write me a message to @awsm9000 and I see what I can do.

Basically it's best practice to copy the theme from the C64, rename it to e.g. C128 and replace the "system.svg" file by the one provided in this package. It would work right away (assuming you managed to setup VICE to show and launch Plus/4, VIC and C128 emulation).

Note that all art has been done by me, with referencing images found on the interwebz. However, I wasn't able to find the exact font for the VIC20, so I used the best approximisation. If you know more about the original fonts used by Commodore for it's labels, please send me a message to @awsm9000! 

Feel free to use the labels for whatever you like.